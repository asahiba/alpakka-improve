# License

## Creative Commons BY-NC-SA 4.0

> **Attribution**: You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
>
> **Non Commercial**: You may not use the material for commercial purposes.
>
> **Share Alike**: If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
>
> **No additional restrictions**: You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

This is a human-readable summary of (and not a substitute for) the complete license [Creative Commons BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).


## Safety
Be sure you (and people around you) always use adequate protective equipment and stay safe. Do NOT leave electrical or electronic equipment running without supervision. Do NOT use this project for medical, transportation, weaponry, law enforcement, nor military purposes.
