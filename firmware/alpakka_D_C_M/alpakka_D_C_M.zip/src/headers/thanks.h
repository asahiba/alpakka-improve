// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2022, Input Labs Oy.

extern uint8_t thanks_len;
extern uint8_t thanks_list[11][24];
