// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2022, Input Labs Oy.

#pragma once

void power_gpio_init();
void power_restart();
void power_bootsel();
void power_dormant();
