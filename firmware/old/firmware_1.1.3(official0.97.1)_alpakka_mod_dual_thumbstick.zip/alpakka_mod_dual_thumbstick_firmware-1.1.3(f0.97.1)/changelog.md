# Changelog

See [Releases](https://github.com/inputlabs/alpakka_firmware/releases).
