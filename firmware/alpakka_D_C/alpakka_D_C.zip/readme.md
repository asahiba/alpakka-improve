https://github.com/inputlabs/alpakka_firmware
